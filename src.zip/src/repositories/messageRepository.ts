import { Pool } from 'pg';

// Define the database connection configuration
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: Number(process.env.DB_PORT),
});

interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  timestamp: Date;
}

/**
 * Repository to handle encrypted message storage.
 */
export const createMessageRepository = () => {
  return {
    /**
     * Stores a new message in the database.
     * @param message The message to store.
     */
    async storeMessage(message: Omit<Message, 'id'>): Promise<Message> {
      try {
        const result = await pool.query(
          'INSERT INTO messages (conversation_id, sender_id, text, timestamp) VALUES ($1, $2, $3, $4) RETURNING id, conversation_id, sender_id, text, timestamp',
          [message.conversationId, message.senderId, message.text, message.timestamp]
        );

        // Assuming the query returns the newly created message
        return {
          id: result.rows[0].id,
          conversationId: result.rows[0].conversation_id,
          senderId: result.rows[0].sender_id,
          text: result.rows[0].text,
          timestamp: result.rows[0].timestamp,
        };
      } catch (error) {
        console.error('Failed to store message:', error);
        throw error;
      }
    },

    /**
     * Retrieves messages for a given conversation ID.
     * @param conversationId The ID of the conversation.
     */
    async getMessagesByConversationId(conversationId: string): Promise<Message[]> {
      try {
        const result = await pool.query(
          'SELECT id, conversation_id, sender_id, text, timestamp FROM messages WHERE conversation_id = $1',
          [conversationId]
        );

        return result.rows.map(row => ({
          id: row.id,
          conversationId: row.conversation_id,
          senderId: row.sender_id,
          text: row.text,
          timestamp: row.timestamp,
        }));
      } catch (error) {
        console.error('Failed to get messages by conversation ID:', error);
        throw error;
      }
    },
  };
};

// Example usage:
const messageRepository = createMessageRepository();

// messageRepository.storeMessage({
//   conversationId: '123',
//   senderId: 'user1',
//   text: 'Hello!',
//   timestamp: new Date(),
// });

// messageRepository.getMessagesByConversationId('123');
